This directory contains the final version of the paper

Supporting Non-Functional Requirements in Services Software Development Process: an MDD Approach

by Valeria de Castro, Martin A. Musicante, Umberto Souza da Costa, Placido A. de Souza~Neto and Genoveva Vargas-Solar

The main file is main.tex. It should be compiled on LaTex using the sequence of commands:

$ pdflatex main.tex
$ bibtex main.tex
$ pdflatex main.tex
$ pdflatex main.tex

The generated file is main.pdf .

The directory also contains the signed copyright release form.

